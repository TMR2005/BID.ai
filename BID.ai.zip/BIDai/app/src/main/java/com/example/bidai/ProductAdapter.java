package com.example.bidai;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;


import com.example.bidai.Product;
import com.example.bidai.R;

import java.util.List;

public class ProductAdapter extends BaseAdapter {

    private Context context;
    private List<Product> productList;

    public ProductAdapter(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
    }

    @Override
    public int getCount() {
        return productList.size();
    }

    @Override
    public Object getItem(int position) {
        return productList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.grid_item_product, null);
        }

        ImageView productImage = convertView.findViewById(R.id.productImage);
        TextView productName = convertView.findViewById(R.id.productName);
        TextView productPrice = convertView.findViewById(R.id.productPrice);
        TextView category = convertView.findViewById(R.id.category);
        TextView status = convertView.findViewById(R.id.status);
        ImageView expand = convertView.findViewById(R.id.expandArrow);
        ImageView min = convertView.findViewById(R.id.up);
        View expandable = convertView.findViewById(R.id.expandableView);

        Product product = productList.get(position);

        productName.setText(product.getPname());
        productPrice.setText("Price: ₹" + product.getPprice());
        category.setText("Category: "+product.getCategory());
        status.setText("Status: "+product.getStatus());
        Glide.with(context)
                .load(product.getImageURL())
                .into(productImage);

        expandable.setVisibility(View.GONE);
        min.setVisibility(View.GONE);
        expand.setVisibility(View.VISIBLE);

        expand.setOnClickListener(v -> {
            expandable.setVisibility(View.VISIBLE);
            expand.setVisibility(View.GONE);
            min.setVisibility(View.VISIBLE);
        });
        min.setOnClickListener(v->{
            expandable.setVisibility(View.GONE);
            expand.setVisibility(View.VISIBLE);
            min.setVisibility(View.GONE);
        });

        if (!product.getImageURL().isEmpty()) {

        }

        return convertView;
    }
}
