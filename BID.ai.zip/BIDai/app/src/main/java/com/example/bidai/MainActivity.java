package com.example.bidai;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bidai.Dashboard;
import com.example.bidai.R;

public class MainActivity extends AppCompatActivity {

    private EditText etPhone;
    private Button btnLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page);

        etPhone = findViewById(R.id.etPhone);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = etPhone.getText().toString().trim();

                if (phone.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a mobile number", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(MainActivity.this, Dashboard.class);
                    intent.putExtra("VENDOR_NAME", "John Doe");
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
