package com.example.bidai;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bidai.R;

public class Dashboard extends AppCompatActivity {

    private TextView tvWelcomeVendor;
    private GridView gridViewProducts;
    private ProductAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard_page);

        tvWelcomeVendor = findViewById(R.id.tvWelcome);
        gridViewProducts = findViewById(R.id.gridViewProducts);

        String vendorName = getIntent().getStringExtra("VENDOR_NAME");
        if (vendorName == null) vendorName = "Vendor";
        tvWelcomeVendor.setText("Welcome " + vendorName);

        Button btnAddProduct = findViewById(R.id.btnAddProduct);
        btnAddProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, AddProduct.class);
                startActivity(intent);
            }
        });

        adapter = new ProductAdapter(this, ProductRepository.productList);
        gridViewProducts.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter.notifyDataSetChanged();
        TextView tvNoOfProducts = findViewById(R.id.nop);
        int totalProducts = ProductRepository.productList.size();
        tvNoOfProducts.setText(String.valueOf(totalProducts));
    }
}
