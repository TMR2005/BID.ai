package com.example.bidai;

public class Product {
    private String Pname;
    private String Pprice;
    private String category;
    private String Status;
    private String ImageURL;

    public Product(String pname, String pprice, String category,String Status, String imageURL) {
        Pname = pname;
        ImageURL = imageURL;
        this.Status = Status;
        this.category = category;
        Pprice = pprice;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getImageURL() {
        return ImageURL;
    }

    public void setImageURL(String imageURL) {
        ImageURL = imageURL;
    }

    public String getPname() {
        return Pname;
    }

    public void setPname(String pname) {
        Pname = pname;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPprice() {
        return Pprice;
    }

    public void setPprice(String pprice) {
        Pprice = pprice;
    }
}
