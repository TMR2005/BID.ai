package com.example.bidai;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;

public class AddProduct extends AppCompatActivity {

    EditText etProductName, etProductPrice, etImageURL;
    Spinner spinnerCategory;
    Button btnAddProduct;
    RadioGroup statusRadioGroup;
    String status = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_product);

        etProductName = findViewById(R.id.etProductName);
        etProductPrice = findViewById(R.id.etProductPrice);
        etImageURL = findViewById(R.id.etImageURL);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        btnAddProduct = findViewById(R.id.btnAddProduct);
        statusRadioGroup = findViewById(R.id.statusRadioGroup);

        String[] categories = {"Machinery", "Nursery", "Chemicals", "Accessories", "Supplies"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                categories
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        statusRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rbActive) {
                    status = "Active";
                } else if (checkedId == R.id.rbInactive) {
                    status = "Inactive";
                } else {
                    status = "Not Applicable";
                }
            }
        });

        btnAddProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etProductName.getText().toString();
                String price = etProductPrice.getText().toString();
                String category = spinnerCategory.getSelectedItem().toString();
                String imageUrl = etImageURL.getText().toString();

                Product product = new Product(name, price, category, status,imageUrl);

                ProductRepository.productList.add(product);

                Toast.makeText(AddProduct.this, "Product Added!", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(AddProduct.this, Dashboard.class);
                intent.putExtra("VENDOR_NAME", "Vendor"); // Pass vendor name again if needed
                startActivity(intent);
                finish();
            }
        });
    }
}
